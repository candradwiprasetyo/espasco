<div class="color_item">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr height="80">
    
    <td align="center" width="5%"><div class="jumlah_meja"><?= get_jumlah_meja($building_id) ?></div></td>
    <td align="center" width="5%">&nbsp;</td>
    <td align="left" width="40%">Jumlah Meja </td>
    </tr>
  </table>
</div>