

<span class="tooltip-text">
<div class="table_total_item" style="margin-bottom:10px; text-align:center;">
Meja masih kosong
</div>

<div class="row">
<div class="form-group">
<div class="col-xs-6" style="padding:0px;"><a href="transaction.php?table_id=<?= $row['table_id']?>" style="text-decoration:none;"><div class="btn_edit_item">ADD ORDER</div></a>
</div>

<div class="col-xs-6" style="padding:0px;">
<a href="order.php?page=merger_table&table_id=<?= $row['table_id']?>&building_id=<?= $building_id?>" style="text-decoration:none;"><div class="btn_print">MERGER</div></a>
</div>
</div>
</div>

   
   
</span>
