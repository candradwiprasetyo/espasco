  <div class="box-footer">
                                
                                <a href="<?= $close_button?>" class="btn btn-danger" >Close</a>
                                <a href="report_event_summary.php?page=download_detail&id=<?= $_GET['id']?>" class="btn btn-danger" >Download</a>
								
								</div>
                            
                    </div>
                            <!-- /.box -->         
                            </div><!--/.col (right) -->
                    </div>   <!-- /.row -->
                </section><!-- /.content -->